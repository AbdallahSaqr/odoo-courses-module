from odoo import models, fields

class Student(models.Model):
    _name = 'courses.student'
    _description = 'Student'

    name = fields.Char(string='Name', required=True)
    code = fields.Char(string='Student Code', required=True)
    birthdate = fields.Date(string='Birth Date')
    address = fields.Text(string='Address')
