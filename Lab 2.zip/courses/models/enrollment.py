from odoo import models, fields

class Enrollment(models.Model):
    _name = 'courses.enrollment'
    _description = 'Course Enrollment'

    name = fields.Char(string='Enrollment Name', required=True)
    student_id = fields.Many2one('courses.student', string='Student', required=True)
    course_id = fields.Many2one('courses.course', string='Course', required=True)
    date = fields.Date(string='Enrollment Date', required=True)
    cost = fields.Float(string='Cost', related='course_id.cost', store=True, readonly=True)
